package gov.epa.eis.batch.frs.writer;

import gov.epa.eis.model.view.SubFacilityCaerFrsView;
import org.springframework.stereotype.Component;

/**
 * Created by DDelVecc on 4/6/2019.
 */
@Component
public class SubFacilityItemWriter extends JsonFileItemWriter<SubFacilityCaerFrsView> {

}
